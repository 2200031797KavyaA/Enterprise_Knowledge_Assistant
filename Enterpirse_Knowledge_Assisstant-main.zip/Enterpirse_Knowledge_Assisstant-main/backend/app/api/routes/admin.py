"""Admin Control Center endpoints.

Everything here requires require_admin - a normal user hitting any of
these paths gets a 403 from the dependency before any handler code runs,
regardless of what the frontend does or doesn't render.
"""
from pydantic import BaseModel
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.dependencies.auth import require_admin
from app.db.database import get_db
from app.models.conversation import Conversation, Message, Feedback
from app.models.document import Document
from app.models.user import User
from app.repositories import audit_repo, conversation_repo, user_repo
from app.schemas.auth import UserOut
from app.schemas.chat import AdminMessageOut, ConversationOut, DebugTrace, RestoreRequestOut, RestoreRequestResolve

router = APIRouter(prefix="/api/admin", tags=["admin"])


# --- Users ----------------------------------------------------------------

@router.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    return [
        UserOut(
            id=u.id, name=u.name, email=u.email, role=u.role, is_active=u.is_active,
            created_at=u.created_at.isoformat(),
            last_login_at=u.last_login_at.isoformat() if u.last_login_at else None,
        )
        for u in user_repo.list_users(db)
    ]


class SetActiveRequest(BaseModel):
    is_active: bool


@router.patch("/users/{user_id}/active", status_code=204)
def set_user_active(user_id: str, payload: SetActiveRequest, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    user = user_repo.get_by_id(db, user_id)
    if not user:
        raise HTTPException(404, "User not found")
    if user.id == admin.id and not payload.is_active:
        raise HTTPException(400, "You cannot deactivate your own account.")
    user_repo.set_active(db, user, payload.is_active)
    audit_repo.log_action(
        db, admin, "USER_STATUS_CHANGE", target_type="user", target_id=user.id,
        metadata={"is_active": payload.is_active},
    )


class SetRoleRequest(BaseModel):
    role: str


@router.patch("/users/{user_id}/role", status_code=204)
def set_user_role(user_id: str, payload: SetRoleRequest, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    if payload.role not in ("USER", "ADMIN"):
        raise HTTPException(400, "Role must be USER or ADMIN.")
    user = user_repo.get_by_id(db, user_id)
    if not user:
        raise HTTPException(404, "User not found")
    if user.id == admin.id and payload.role != "ADMIN":
        raise HTTPException(400, "You cannot remove your own admin role.")
    user_repo.set_role(db, user, payload.role)
    audit_repo.log_action(
        db, admin, "USER_ROLE_CHANGE", target_type="user", target_id=user.id, metadata={"role": payload.role}
    )


# --- Conversation recovery --------------------------------------------------

class AdminConversationOut(BaseModel):
    id: str
    title: str
    owner_id: str | None
    owner_email: str | None
    created_at: str
    is_deleted: bool
    deleted_at: str | None
    deleted_by: str | None


@router.get("/conversations", response_model=list[AdminConversationOut])
def list_all_conversations(
    include_deleted: bool = True,
    owner_id: str | None = None,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    convs = conversation_repo.list_all_conversations_admin(db, include_deleted=include_deleted, owner_id=owner_id)
    out = []
    for c in convs:
        owner = user_repo.get_by_id(db, c.user_id) if c.user_id else None
        out.append(
            AdminConversationOut(
                id=c.id, title=c.title, owner_id=c.user_id, owner_email=owner.email if owner else None,
                created_at=c.created_at.isoformat(), is_deleted=c.is_deleted,
                deleted_at=c.deleted_at.isoformat() if c.deleted_at else None, deleted_by=c.deleted_by,
            )
        )
    return out


@router.get("/conversations/{conversation_id}/messages", response_model=list[AdminMessageOut])
def admin_get_conversation_messages(
    conversation_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin)
):
    """Full-fidelity thread for ANY user's conversation, including the
    complete RAG pipeline trace (query rewrite, retrieval, rerank, timings,
    LLM backend) captured at the moment each question was answered. This is
    what powers the 'how was this query actually processed' view in the
    Admin Control Center - it reads the debug_trace that was already
    persisted per-message at answer time, it does not re-run the pipeline."""
    conv = conversation_repo.get_conversation_any_owner(db, conversation_id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    out = []
    for m in conv.messages:
        debug = DebugTrace(**m.debug_trace) if m.debug_trace else None
        out.append(
            AdminMessageOut(
                id=m.id, role=m.role, content=m.content, sources=m.sources,
                debug=debug, created_at=m.created_at.isoformat(),
            )
        )
    return out


@router.post("/conversations/{conversation_id}/restore", status_code=204)
def admin_restore_conversation(conversation_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    conv = conversation_repo.get_conversation_any_owner(db, conversation_id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    conversation_repo.restore_conversation(db, conv)
    audit_repo.log_action(db, admin, "CONVERSATION_RESTORE", target_type="conversation", target_id=conv.id)


@router.delete("/conversations/{conversation_id}/permanent", status_code=204)
def admin_permanently_delete_conversation(conversation_id: str, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    conv = conversation_repo.get_conversation_any_owner(db, conversation_id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    conversation_repo.hard_delete_conversation(db, conv)
    audit_repo.log_action(db, admin, "CONVERSATION_PERMANENT_DELETE", target_type="conversation", target_id=conversation_id)


# --- Restore requests -------------------------------------------------------

@router.get("/restore-requests", response_model=list[RestoreRequestOut])
def list_restore_requests(status: str | None = None, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    reqs = conversation_repo.list_restore_requests(db, status=status)
    out = []
    for r in reqs:
        conv = conversation_repo.get_conversation_any_owner(db, r.conversation_id)
        out.append(
            RestoreRequestOut(
                id=r.id, conversation_id=r.conversation_id, conversation_title=conv.title if conv else None,
                requested_by=r.requested_by, reason=r.reason, status=r.status, resolved_by=r.resolved_by,
                resolution_reason=r.resolution_reason, requested_at=r.requested_at.isoformat(),
                resolved_at=r.resolved_at.isoformat() if r.resolved_at else None,
            )
        )
    return out


@router.post("/restore-requests/{request_id}/resolve", status_code=204)
def resolve_restore_request(
    request_id: str, payload: RestoreRequestResolve, db: Session = Depends(get_db), admin: User = Depends(require_admin)
):
    req = conversation_repo.get_restore_request(db, request_id)
    if not req:
        raise HTTPException(404, "Restore request not found")
    if req.status != "PENDING":
        raise HTTPException(400, "This request has already been resolved.")

    conversation_repo.resolve_restore_request(db, req, payload.approve, admin.id, payload.resolution_reason)
    if payload.approve:
        conv = conversation_repo.get_conversation_any_owner(db, req.conversation_id)
        if conv:
            conversation_repo.restore_conversation(db, conv)

    audit_repo.log_action(
        db, admin, "RESTORE_REQUEST_APPROVE" if payload.approve else "RESTORE_REQUEST_REJECT",
        target_type="restore_request", target_id=req.id,
    )


# --- Audit log ---------------------------------------------------------------

class AuditLogOut(BaseModel):
    id: str
    actor_email: str | None
    action: str
    target_type: str | None
    target_id: str | None
    status: str
    created_at: str


@router.get("/audit-logs", response_model=list[AuditLogOut])
def get_audit_logs(limit: int = 200, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    logs = audit_repo.list_logs(db, limit=limit)
    return [
        AuditLogOut(
            id=l.id, actor_email=l.actor_email, action=l.action, target_type=l.target_type,
            target_id=l.target_id, status=l.status, created_at=l.created_at.isoformat(),
        )
        for l in logs
    ]


# --- Analytics (real counts only - never fabricated) ------------------------

@router.get("/analytics/overview")
def analytics_overview(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    total_users = db.query(User).count()
    active_users = db.query(User).filter(User.is_active.is_(True)).count()
    total_conversations = db.query(Conversation).count()
    deleted_conversations = db.query(Conversation).filter(Conversation.is_deleted.is_(True)).count()
    total_messages = db.query(Message).count()
    total_documents = db.query(Document).count()
    positive_feedback = db.query(Feedback).filter(Feedback.rating == 1).count()
    negative_feedback = db.query(Feedback).filter(Feedback.rating == -1).count()
    pending_restore_requests = len(conversation_repo.list_restore_requests(db, status="PENDING"))

    return {
        "total_users": total_users,
        "active_users": active_users,
        "total_conversations": total_conversations,
        "deleted_conversations": deleted_conversations,
        "total_messages": total_messages,
        "total_documents": total_documents,
        "positive_feedback": positive_feedback,
        "negative_feedback": negative_feedback,
        "pending_restore_requests": pending_restore_requests,
    }
