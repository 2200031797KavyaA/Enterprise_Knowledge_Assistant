"""Authentication and account-management endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.dependencies.auth import get_current_user
from app.core.security import (
    create_access_token,
    hash_password,
    is_password_strong,
    password_requirements_report,
    verify_password,
)
from app.db.database import get_db
from app.models.user import User
from app.repositories import audit_repo, user_repo
from app.schemas.auth import (
    ChangePasswordRequest,
    LoginRequest,
    PasswordRequirementsOut,
    RegisterRequest,
    TokenResponse,
    UpdateProfileRequest,
    UserOut,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        name=user.name,
        email=user.email,
        role=user.role,
        is_active=user.is_active,
        created_at=user.created_at.isoformat(),
        last_login_at=user.last_login_at.isoformat() if user.last_login_at else None,
    )


@router.get("/password-requirements", response_model=PasswordRequirementsOut)
def check_password_requirements(password: str):
    report = password_requirements_report(password)
    return PasswordRequirementsOut(**report, overall_valid=all(report.values()))


@router.post("/register", response_model=TokenResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if payload.password != payload.confirm_password:
        raise HTTPException(400, "Passwords do not match.")
    if not is_password_strong(payload.password):
        raise HTTPException(
            400,
            "Password must be at least 8 characters and include an uppercase letter, "
            "a lowercase letter, a number, and a special character.",
        )
    if user_repo.get_by_email(db, payload.email):
        raise HTTPException(409, "An account with this email already exists.")

    user = user_repo.create_user(
        db, name=payload.name, email=payload.email, password_hash=hash_password(payload.password), role="USER"
    )
    audit_repo.log_action(db, user, "REGISTER", target_type="user", target_id=user.id)

    token = create_access_token(user.id, user.role)
    return TokenResponse(access_token=token, user=_user_out(user))


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    invalid = HTTPException(401, "Incorrect email or password.")
    user = user_repo.get_by_email(db, payload.email)
    if not user or not verify_password(payload.password, user.password_hash):
        raise invalid
    if not user.is_active:
        raise HTTPException(403, "This account has been deactivated.")

    user_repo.set_last_login(db, user)
    audit_repo.log_action(db, user, "LOGIN", target_type="user", target_id=user.id)

    token = create_access_token(user.id, user.role)
    return TokenResponse(access_token=token, user=_user_out(user))


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return _user_out(current_user)


@router.patch("/me", response_model=UserOut)
def update_me(payload: UpdateProfileRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    user = user_repo.update_profile(db, current_user, payload.name)
    audit_repo.log_action(db, current_user, "PROFILE_UPDATE", target_type="user", target_id=user.id)
    return _user_out(user)


@router.post("/change-password", status_code=204)
def change_password(
    payload: ChangePasswordRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    if not verify_password(payload.current_password, current_user.password_hash):
        raise HTTPException(400, "Current password is incorrect.")
    if payload.new_password != payload.confirm_new_password:
        raise HTTPException(400, "New passwords do not match.")
    if not is_password_strong(payload.new_password):
        raise HTTPException(
            400,
            "Password must be at least 8 characters and include an uppercase letter, "
            "a lowercase letter, a number, and a special character.",
        )
    user_repo.set_password(db, current_user, hash_password(payload.new_password))
    audit_repo.log_action(db, current_user, "PASSWORD_CHANGE", target_type="user", target_id=current_user.id)
