"""Chat / RAG query endpoint."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.dependencies.auth import get_current_user
from app.db.database import get_db
from app.models.user import User
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.chat_service import answer_question

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat(payload: ChatRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    try:
        conversation, message, answer, sources, debug_trace, grounded = await answer_question(
            db, payload.conversation_id, payload.message, user_id=current_user.id
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, f"Unable to generate an answer right now.") from e

    # Full RAG execution trace (retrieved chunks, scores, prompt preview) is
    # an admin-only diagnostic view - regular users only ever see the
    # user-safe `sources` list (filename + relevance), never raw chunk text
    # or internal retrieval/ranking internals.
    # sources always carries filename/section/relevance only (see SourceRef) -
    # strip any legacy 'excerpt' key defensively so raw chunk text never
    # reaches a non-admin client regardless of what chat_service produced.
    safe_sources = [{k: v for k, v in s.items() if k != "excerpt"} for s in sources]

    return ChatResponse(
        conversation_id=conversation.id,
        message_id=message.id,
        answer=answer,
        sources=safe_sources,
        debug=debug_trace if current_user.role == "ADMIN" else None,
        grounded=grounded,
    )
