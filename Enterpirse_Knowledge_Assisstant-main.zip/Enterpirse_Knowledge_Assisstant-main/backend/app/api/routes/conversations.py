"""Conversation history endpoints - strictly scoped to the authenticated user.

Ownership is always derived from the JWT (current_user.id), never from a
conversation_id or user_id supplied by the client. See conversation_repo
for the ownership-filtered queries this relies on.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.dependencies.auth import get_current_user
from app.db.database import get_db
from app.models.user import User
from app.repositories import audit_repo, conversation_repo
from app.schemas.chat import (
    ConversationOut,
    MessageOut,
    RestoreRequestCreate,
    RestoreRequestOut,
)

router = APIRouter(prefix="/api/conversations", tags=["conversations"])


def _restore_req_out(req, conv_title: str | None = None) -> RestoreRequestOut:
    return RestoreRequestOut(
        id=req.id,
        conversation_id=req.conversation_id,
        conversation_title=conv_title,
        requested_by=req.requested_by,
        reason=req.reason,
        status=req.status,
        resolved_by=req.resolved_by,
        resolution_reason=req.resolution_reason,
        requested_at=req.requested_at.isoformat(),
        resolved_at=req.resolved_at.isoformat() if req.resolved_at else None,
    )


@router.get("", response_model=list[ConversationOut])
def list_conversations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    convs = conversation_repo.list_conversations(db, user_id=current_user.id)
    return [ConversationOut(id=c.id, title=c.title, created_at=c.created_at.isoformat()) for c in convs]


@router.get("/deleted", response_model=list[ConversationOut])
def list_deleted_conversations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """The user's own soft-deleted conversations, so they have something to
    point at when submitting a restore request. Never another user's."""
    convs = conversation_repo.list_deleted_conversations_for_user(db, user_id=current_user.id)
    return [ConversationOut(id=c.id, title=c.title, created_at=c.created_at.isoformat()) for c in convs]


@router.get("/{conversation_id}/messages", response_model=list[MessageOut])
def get_messages(conversation_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    conv = conversation_repo.get_conversation(db, conversation_id, user_id=current_user.id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    return [
        MessageOut(id=m.id, role=m.role, content=m.content, sources=m.sources, created_at=m.created_at.isoformat())
        for m in conv.messages
    ]


@router.delete("/{conversation_id}", status_code=204)
def delete_conversation(conversation_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Soft delete only. Users can never hard-delete or directly restore -
    restoration requires an admin-approved restore request (see below)."""
    conv = conversation_repo.get_conversation(db, conversation_id, user_id=current_user.id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    conversation_repo.soft_delete_conversation(db, conv, deleted_by_user_id=current_user.id)
    audit_repo.log_action(db, current_user, "CONVERSATION_DELETE", target_type="conversation", target_id=conv.id)


@router.post("/{conversation_id}/restore-requests", response_model=RestoreRequestOut, status_code=201)
def request_restore(
    conversation_id: str,
    payload: RestoreRequestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    conv = conversation_repo.get_conversation_any_owner(db, conversation_id)
    if not conv or conv.user_id != current_user.id:
        raise HTTPException(404, "Conversation not found")
    if not conv.is_deleted:
        raise HTTPException(400, "This conversation isn't deleted, so there's nothing to restore.")

    req = conversation_repo.create_restore_request(db, conversation_id, current_user.id, payload.reason)
    audit_repo.log_action(db, current_user, "RESTORE_REQUEST_SUBMIT", target_type="conversation", target_id=conv.id)
    return _restore_req_out(req, conv.title)


@router.get("/restore-requests/mine", response_model=list[RestoreRequestOut])
def my_restore_requests(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    reqs = conversation_repo.list_restore_requests_for_user(db, current_user.id)
    out = []
    for r in reqs:
        conv = conversation_repo.get_conversation_any_owner(db, r.conversation_id)
        out.append(_restore_req_out(r, conv.title if conv else None))
    return out
