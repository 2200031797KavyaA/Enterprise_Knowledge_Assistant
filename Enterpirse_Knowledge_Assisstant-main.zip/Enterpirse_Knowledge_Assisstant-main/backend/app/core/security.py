"""Password hashing, JWT issuance/validation, and password strength rules."""
import re
from datetime import datetime, timedelta, timezone

from jose import jwt, JWTError
from passlib.context import CryptContext

from app.core.config import get_settings

settings = get_settings()
_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

PASSWORD_RULES = {
    "min_length": lambda p: len(p) >= 8,
    "uppercase": lambda p: bool(re.search(r"[A-Z]", p)),
    "lowercase": lambda p: bool(re.search(r"[a-z]", p)),
    "number": lambda p: bool(re.search(r"\d", p)),
    "special": lambda p: bool(re.search(r"[^A-Za-z0-9]", p)),
}


def password_requirements_report(password: str) -> dict[str, bool]:
    return {name: check(password) for name, check in PASSWORD_RULES.items()}


def is_password_strong(password: str) -> bool:
    return all(password_requirements_report(password).values())


def hash_password(password: str) -> str:
    return _pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return _pwd_context.verify(plain, hashed)


def create_access_token(user_id: str, role: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.jwt_expire_minutes)
    payload = {"sub": user_id, "role": role, "exp": expire}
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    except JWTError:
        return None
