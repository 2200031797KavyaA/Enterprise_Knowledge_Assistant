"""Data access for conversations, messages, feedback, and restore requests."""
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.audit import RestoreRequest
from app.models.conversation import Conversation, Message, Feedback


def get_or_create_conversation(
    db: Session, conversation_id: str | None, title_hint: str, user_id: str | None
) -> Conversation:
    if conversation_id:
        conv = (
            db.query(Conversation)
            .filter(Conversation.id == conversation_id, Conversation.user_id == user_id)
            .first()
        )
        if conv:
            return conv
    title = (title_hint[:60] + "...") if len(title_hint) > 60 else title_hint
    conv = Conversation(title=title or "New conversation", user_id=user_id)
    db.add(conv)
    db.commit()
    db.refresh(conv)
    return conv


def add_message(
    db: Session, conversation_id: str, role: str, content: str, sources: list | None = None, debug_trace: dict | None = None
) -> Message:
    msg = Message(conversation_id=conversation_id, role=role, content=content, sources=sources, debug_trace=debug_trace)
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg


def list_conversations(db: Session, user_id: str) -> list[Conversation]:
    """Active (non-deleted) conversations owned by this user. Never let the
    frontend pass an arbitrary user_id here - always the authenticated id."""
    return (
        db.query(Conversation)
        .filter(Conversation.user_id == user_id, Conversation.is_deleted.is_(False))
        .order_by(Conversation.created_at.desc())
        .all()
    )


def get_conversation(db: Session, conversation_id: str, user_id: str) -> Conversation | None:
    """Ownership-scoped lookup for normal users - excludes soft-deleted rows."""
    return (
        db.query(Conversation)
        .filter(
            Conversation.id == conversation_id,
            Conversation.user_id == user_id,
            Conversation.is_deleted.is_(False),
        )
        .first()
    )


def get_conversation_any_owner(db: Session, conversation_id: str) -> Conversation | None:
    """Admin-only: fetch a conversation regardless of owner or delete state."""
    return db.query(Conversation).filter(Conversation.id == conversation_id).first()


def soft_delete_conversation(db: Session, conv: Conversation, deleted_by_user_id: str) -> None:
    conv.is_deleted = True
    conv.deleted_at = datetime.now(timezone.utc)
    conv.deleted_by = deleted_by_user_id
    db.commit()


def restore_conversation(db: Session, conv: Conversation) -> None:
    conv.is_deleted = False
    conv.deleted_at = None
    conv.deleted_by = None
    db.commit()


def hard_delete_conversation(db: Session, conv: Conversation) -> None:
    db.delete(conv)
    db.commit()


def list_deleted_conversations_for_user(db: Session, user_id: str) -> list[Conversation]:
    return (
        db.query(Conversation)
        .filter(Conversation.user_id == user_id, Conversation.is_deleted.is_(True))
        .order_by(Conversation.deleted_at.desc())
        .all()
    )


def list_all_conversations_admin(
    db: Session, include_deleted: bool = True, owner_id: str | None = None
) -> list[Conversation]:
    q = db.query(Conversation)
    if owner_id:
        q = q.filter(Conversation.user_id == owner_id)
    if not include_deleted:
        q = q.filter(Conversation.is_deleted.is_(False))
    return q.order_by(Conversation.created_at.desc()).all()


def add_feedback(db: Session, message_id: str, rating: int, comment: str | None) -> Feedback:
    fb = Feedback(message_id=message_id, rating=rating, comment=comment)
    db.add(fb)
    db.commit()
    db.refresh(fb)
    return fb


# --- Restore requests ---------------------------------------------------

def create_restore_request(db: Session, conversation_id: str, requested_by: str, reason: str) -> RestoreRequest:
    req = RestoreRequest(conversation_id=conversation_id, requested_by=requested_by, reason=reason)
    db.add(req)
    db.commit()
    db.refresh(req)
    return req


def list_restore_requests(db: Session, status: str | None = None) -> list[RestoreRequest]:
    q = db.query(RestoreRequest)
    if status:
        q = q.filter(RestoreRequest.status == status)
    return q.order_by(RestoreRequest.requested_at.desc()).all()


def list_restore_requests_for_user(db: Session, user_id: str) -> list[RestoreRequest]:
    return (
        db.query(RestoreRequest)
        .filter(RestoreRequest.requested_by == user_id)
        .order_by(RestoreRequest.requested_at.desc())
        .all()
    )


def get_restore_request(db: Session, request_id: str) -> RestoreRequest | None:
    return db.query(RestoreRequest).filter(RestoreRequest.id == request_id).first()


def resolve_restore_request(
    db: Session, req: RestoreRequest, approve: bool, resolved_by: str, resolution_reason: str | None
) -> None:
    req.status = "APPROVED" if approve else "REJECTED"
    req.resolved_by = resolved_by
    req.resolution_reason = resolution_reason
    req.resolved_at = datetime.now(timezone.utc)
    db.commit()
