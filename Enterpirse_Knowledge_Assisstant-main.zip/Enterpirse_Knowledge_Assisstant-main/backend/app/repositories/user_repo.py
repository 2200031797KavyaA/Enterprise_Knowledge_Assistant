"""Data access for users."""
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models.user import User


def get_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email.lower()).first()


def get_by_id(db: Session, user_id: str) -> User | None:
    return db.query(User).filter(User.id == user_id).first()


def create_user(db: Session, name: str, email: str, password_hash: str, role: str = "USER") -> User:
    user = User(name=name, email=email.lower(), password_hash=password_hash, role=role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def list_users(db: Session) -> list[User]:
    return db.query(User).order_by(User.created_at.desc()).all()


def set_last_login(db: Session, user: User) -> None:
    user.last_login_at = datetime.now(timezone.utc)
    db.commit()


def set_active(db: Session, user: User, is_active: bool) -> None:
    user.is_active = is_active
    db.commit()


def set_role(db: Session, user: User, role: str) -> None:
    user.role = role
    db.commit()


def update_profile(db: Session, user: User, name: str | None) -> User:
    if name:
        user.name = name
    db.commit()
    db.refresh(user)
    return user


def set_password(db: Session, user: User, password_hash: str) -> None:
    user.password_hash = password_hash
    db.commit()
