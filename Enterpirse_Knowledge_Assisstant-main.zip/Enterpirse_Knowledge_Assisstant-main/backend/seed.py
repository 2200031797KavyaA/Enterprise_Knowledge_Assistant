"""
Seed script: ingests the sample HR/IT documents into the database.
Run with: python seed.py
"""
import asyncio
import glob
import os

from app.db.database import SessionLocal, init_db
from app.services.document_service import ingest_document
from app.repositories import document_repo, user_repo
from app.core.security import hash_password

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "data", "sample_docs")

# Default accounts for local/dev use only. Change these passwords (or delete
# these accounts) before any real deployment - seed.py is not run in prod.
DEFAULT_ADMIN = {"name": "Admin", "email": "admin@gmail.com", "password": "Admin@12345"}
DEFAULT_USER = {"name": "Demo User", "email": "user@gmail.com", "password": "User@12345"}


def seed_default_users(db):
    if not user_repo.get_by_email(db, DEFAULT_ADMIN["email"]):
        user_repo.create_user(
            db, DEFAULT_ADMIN["name"], DEFAULT_ADMIN["email"], hash_password(DEFAULT_ADMIN["password"]), role="ADMIN"
        )
        print(f"created default admin: {DEFAULT_ADMIN['email']} / {DEFAULT_ADMIN['password']}")
    if not user_repo.get_by_email(db, DEFAULT_USER["email"]):
        user_repo.create_user(
            db, DEFAULT_USER["name"], DEFAULT_USER["email"], hash_password(DEFAULT_USER["password"]), role="USER"
        )
        print(f"created default user: {DEFAULT_USER['email']} / {DEFAULT_USER['password']}")

CATEGORY_BY_FILE = {
    "leave_policy.txt": "HR",
    "expense_reimbursement.txt": "Finance",
    "it_password_reset.txt": "IT",
    "remote_work_policy.md": "HR",
}


async def main():
    init_db()
    db = SessionLocal()
    try:
        seed_default_users(db)
        existing = {d.filename for d in document_repo.list_documents(db)}
        for path in sorted(glob.glob(os.path.join(SAMPLE_DIR, "*"))):
            filename = os.path.basename(path)
            if filename in existing:
                print(f"skip (already ingested): {filename}")
                continue
            with open(path, "rb") as f:
                raw = f.read()
            category = CATEGORY_BY_FILE.get(filename, "General")
            doc = await ingest_document(db, filename, raw, category)
            print(f"ingested: {filename} -> {doc.chunk_count} chunks ({doc.status})")
    finally:
        db.close()


if __name__ == "__main__":
    asyncio.run(main())
