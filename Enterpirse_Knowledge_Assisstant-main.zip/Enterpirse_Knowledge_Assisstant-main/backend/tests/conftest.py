"""Shared pytest fixtures: an isolated SQLite DB + Chroma dir per test."""
import shutil
import tempfile

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="function")
def client(monkeypatch):
    tmp_dir = tempfile.mkdtemp()
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_dir}/test.db")
    monkeypatch.setenv("CHROMA_PERSIST_DIR", f"{tmp_dir}/chroma")
    monkeypatch.setenv("JWT_SECRET_KEY", "test-secret-not-for-production")

    from app.core.config import get_settings
    get_settings.cache_clear()

    import app.db.database as database_module
    import app.rag.vector_store as vector_store_module
    database_module.reset_for_tests()
    vector_store_module.reset_for_tests()

    from app.main import app
    with TestClient(app) as c:
        yield c

    database_module.reset_for_tests()
    vector_store_module.reset_for_tests()
    shutil.rmtree(tmp_dir, ignore_errors=True)


def _register(client, email, password="Testpass1!", name="Test User"):
    resp = client.post(
        "/api/auth/register",
        json={"name": name, "email": email, "password": password, "confirm_password": password},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["access_token"]


@pytest.fixture
def user_token(client):
    """A plain USER account's JWT."""
    return _register(client, "member@example.com")


@pytest.fixture
def admin_token(client):
    """A separate account, registered then promoted to ADMIN via the DB
    directly (there's no API for self-promotion, by design). Kept as a
    distinct identity from user_token so cross-user/role tests are valid."""
    import app.db.database as database_module
    from app.repositories import user_repo

    _register(client, "admin-test@example.com", password="Testpass1!")

    db = database_module.SessionLocal()
    try:
        user = user_repo.get_by_email(db, "admin-test@example.com")
        user_repo.set_role(db, user, "ADMIN")
    finally:
        db.close()

    resp = client.post("/api/auth/login", json={"email": "admin-test@example.com", "password": "Testpass1!"})
    assert resp.status_code == 200
    return resp.json()["access_token"]


@pytest.fixture
def auth_headers(user_token):
    return {"Authorization": f"Bearer {user_token}"}


@pytest.fixture
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}
