def test_admin_can_view_any_users_pipeline_trace(client, auth_headers, admin_headers):
    resp = client.post("/api/chat", json={"message": "What is the WFH policy?"}, headers=auth_headers)
    assert resp.status_code == 200
    conv_id = resp.json()["conversation_id"]

    convs = client.get("/api/admin/conversations", headers=admin_headers).json()
    assert any(c["id"] == conv_id for c in convs)

    msgs = client.get(f"/api/admin/conversations/{conv_id}/messages", headers=admin_headers)
    assert msgs.status_code == 200
    body = msgs.json()
    assert len(body) == 2
    assistant_msg = [m for m in body if m["role"] == "assistant"][0]
    assert assistant_msg["debug"] is not None
    assert "timings_ms" in assistant_msg["debug"]
    assert "total_ms" in assistant_msg["debug"]["timings_ms"]
    assert assistant_msg["debug"]["original_query"] == "What is the WFH policy?"
    assert assistant_msg["sources"] is not None

    # A plain user must never reach this admin-only endpoint.
    forbidden = client.get(f"/api/admin/conversations/{conv_id}/messages", headers=auth_headers)
    assert forbidden.status_code == 403
