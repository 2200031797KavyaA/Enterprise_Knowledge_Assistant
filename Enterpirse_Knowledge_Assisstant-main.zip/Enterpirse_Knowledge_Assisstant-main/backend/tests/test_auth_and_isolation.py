"""Auth, RBAC, and cross-user isolation tests - the core security guarantees
called out throughout the spec: a user must never reach another user's data
or admin-only endpoints, no matter what IDs they pass."""


def test_register_rejects_weak_password(client):
    resp = client.post(
        "/api/auth/register",
        json={"name": "Weak", "email": "weak@example.com", "password": "weakpass", "confirm_password": "weakpass"},
    )
    assert resp.status_code == 400


def test_register_rejects_mismatched_passwords(client):
    resp = client.post(
        "/api/auth/register",
        json={"name": "A", "email": "a@example.com", "password": "Strongpass1!", "confirm_password": "Different1!"},
    )
    assert resp.status_code == 400


def test_register_rejects_duplicate_email(client, user_token):  # noqa: ARG001 - fixture registers the email
    resp = client.post(
        "/api/auth/register",
        json={"name": "Dup", "email": "member@example.com", "password": "Strongpass1!", "confirm_password": "Strongpass1!"},
    )
    assert resp.status_code == 409


def test_login_rejects_wrong_password(client, user_token):  # noqa: ARG001
    resp = client.post("/api/auth/login", json={"email": "member@example.com", "password": "WrongPass1!"})
    assert resp.status_code == 401


def test_login_rejects_unknown_user(client):
    resp = client.post("/api/auth/login", json={"email": "nobody@example.com", "password": "whatever1!"})
    assert resp.status_code == 401


def test_protected_route_rejects_missing_token(client):
    resp = client.get("/api/conversations")
    assert resp.status_code == 401


def test_protected_route_rejects_garbage_token(client):
    resp = client.get("/api/conversations", headers={"Authorization": "Bearer not-a-real-token"})
    assert resp.status_code == 401


def test_non_admin_cannot_reach_admin_routes(client, auth_headers):
    for path in ["/api/admin/users", "/api/admin/conversations", "/api/admin/audit-logs", "/api/admin/analytics/overview"]:
        resp = client.get(path, headers=auth_headers)
        assert resp.status_code == 403, path


def test_user_cannot_read_another_users_conversation(client, auth_headers, admin_headers):
    # admin creates a conversation (admins are users too, for chat purposes)
    resp = client.post("/api/chat", json={"message": "hello"}, headers=admin_headers)
    other_conv_id = resp.json()["conversation_id"]

    # the plain user tries to read it directly by ID - must not succeed
    resp = client.get(f"/api/conversations/{other_conv_id}/messages", headers=auth_headers)
    assert resp.status_code == 404

    resp = client.delete(f"/api/conversations/{other_conv_id}", headers=auth_headers)
    assert resp.status_code == 404


def test_conversation_list_never_leaks_other_users_conversations(client, auth_headers, admin_headers):
    client.post("/api/chat", json={"message": "admin's own question"}, headers=admin_headers)
    resp = client.post("/api/chat", json={"message": "user's own question"}, headers=auth_headers)
    my_conv_id = resp.json()["conversation_id"]

    listing = client.get("/api/conversations", headers=auth_headers).json()
    ids = {c["id"] for c in listing}
    assert my_conv_id in ids
    assert len(listing) == 1  # never sees the admin's conversation


def test_soft_delete_then_restore_request_then_admin_approval_flow(client, auth_headers, admin_headers):
    resp = client.post("/api/chat", json={"message": "please remember this"}, headers=auth_headers)
    conv_id = resp.json()["conversation_id"]

    # delete is soft - conversation disappears from the active list...
    assert client.delete(f"/api/conversations/{conv_id}", headers=auth_headers).status_code == 204
    assert conv_id not in {c["id"] for c in client.get("/api/conversations", headers=auth_headers).json()}

    # ...but the user can still see it in their own deleted list to request restoration
    deleted = client.get("/api/conversations/deleted", headers=auth_headers).json()
    assert conv_id in {c["id"] for c in deleted}

    # user cannot restore it directly - there is no such endpoint for users,
    # only a restore-request they can submit
    resp = client.post(
        f"/api/conversations/{conv_id}/restore-requests", json={"reason": "needed for reference"}, headers=auth_headers
    )
    assert resp.status_code == 201
    request_id = resp.json()["id"]

    # admin approves -> conversation reappears in the user's active list
    resp = client.post(
        f"/api/admin/restore-requests/{request_id}/resolve", json={"approve": True}, headers=admin_headers
    )
    assert resp.status_code == 204
    assert conv_id in {c["id"] for c in client.get("/api/conversations", headers=auth_headers).json()}


def test_admin_sees_all_conversations_including_deleted(client, auth_headers, admin_headers):
    resp = client.post("/api/chat", json={"message": "will be deleted"}, headers=auth_headers)
    conv_id = resp.json()["conversation_id"]
    client.delete(f"/api/conversations/{conv_id}", headers=auth_headers)

    admin_view = client.get("/api/admin/conversations", headers=admin_headers).json()
    ids = {c["id"] for c in admin_view}
    assert conv_id in ids
    row = next(c for c in admin_view if c["id"] == conv_id)
    assert row["is_deleted"] is True
    assert row["deleted_by"] is not None


def test_admin_cannot_deactivate_own_account(client, admin_headers):
    me = client.get("/api/auth/me", headers=admin_headers).json()
    resp = client.patch(f"/api/admin/users/{me['id']}/active", json={"is_active": False}, headers=admin_headers)
    assert resp.status_code == 400


def test_change_password_requires_correct_current_password(client, auth_headers):
    resp = client.post(
        "/api/auth/change-password",
        json={"current_password": "WrongCurrent1!", "new_password": "NewStrong1!", "confirm_new_password": "NewStrong1!"},
        headers=auth_headers,
    )
    assert resp.status_code == 400
