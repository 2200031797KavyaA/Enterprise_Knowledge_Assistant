"""API-level tests for document ingestion (admin-only) and the chat endpoint
(local fallback mode), including the auth/RBAC boundaries around both."""
import io


def test_upload_requires_authentication(client):
    resp = client.post(
        "/api/documents",
        files={"file": ("leave.txt", io.BytesIO(b"content"), "text/plain")},
        data={"category": "HR"},
    )
    assert resp.status_code == 401


def test_upload_rejected_for_non_admin(client, auth_headers):
    resp = client.post(
        "/api/documents",
        files={"file": ("leave.txt", io.BytesIO(b"content"), "text/plain")},
        data={"category": "HR"},
        headers=auth_headers,
    )
    assert resp.status_code == 403


def test_upload_rejects_unsupported_extension(client, admin_headers):
    resp = client.post(
        "/api/documents",
        files={"file": ("notes.exe", io.BytesIO(b"not a real doc"), "application/octet-stream")},
        data={"category": "General"},
        headers=admin_headers,
    )
    assert resp.status_code == 400


def test_upload_and_ingest_txt_document(client, admin_headers):
    content = b"LEAVE POLICY\nEmployees get 18 days of annual leave per year."
    resp = client.post(
        "/api/documents",
        files={"file": ("leave.txt", io.BytesIO(content), "text/plain")},
        data={"category": "HR"},
        headers=admin_headers,
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["status"] == "ready"
    assert body["chunk_count"] >= 1

    listing = client.get("/api/documents", headers=admin_headers).json()
    assert any(d["filename"] == "leave.txt" for d in listing)


def test_chat_without_documents_is_not_grounded(client, auth_headers):
    resp = client.post("/api/chat", json={"message": "What is the leave policy?"}, headers=auth_headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["grounded"] is False
    assert body["sources"] == []


def test_chat_requires_authentication(client):
    resp = client.post("/api/chat", json={"message": "What is the leave policy?"})
    assert resp.status_code == 401


def test_chat_grounds_answer_in_uploaded_document(client, admin_headers, auth_headers):
    content = b"IT SUPPORT\nTo reset your password, visit the self-service portal."
    client.post(
        "/api/documents",
        files={"file": ("it.txt", io.BytesIO(content), "text/plain")},
        data={"category": "IT"},
        headers=admin_headers,
    )
    resp = client.post("/api/chat", json={"message": "How do I reset my password?"}, headers=auth_headers)
    body = resp.json()
    assert body["grounded"] is True
    assert any(s["filename"] == "it.txt" for s in body["sources"])
    # non-admin never receives the debug trace, and sources never carry raw excerpt text
    assert body["debug"] is None
    assert all("excerpt" not in s for s in body["sources"])


def test_chat_returns_debug_trace_for_admin(client, admin_headers):
    resp = client.post("/api/chat", json={"message": "hello"}, headers=admin_headers)
    body = resp.json()
    assert body["debug"] is not None
    assert "embedding_backend" in body["debug"]
