import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ToastProvider } from "./context/ToastContext";
import { AuthProvider } from "./context/AuthContext";
import { RequireAuth, RequireAdmin, RedirectIfAuthed } from "./components/RouteGuards";

import { LoginPage } from "./pages/auth/LoginPage";
import { RegisterPage } from "./pages/auth/RegisterPage";

import { UserLayout } from "./layouts/UserLayout";
import { OverviewPage } from "./pages/user/OverviewPage";
import { ChatsListPage } from "./pages/user/ChatsListPage";
import { ChatRoute } from "./pages/user/ChatRoute";
import { DeletedChatsPage } from "./pages/user/DeletedChatsPage";
import { ProfilePage } from "./pages/user/ProfilePage";
import { SettingsPage } from "./pages/user/SettingsPage";

import { AdminLayout } from "./layouts/AdminLayout";
import { AdminOverviewPage } from "./pages/admin/AdminOverviewPage";
import { AdminUsersPage } from "./pages/admin/AdminUsersPage";
import { DocumentsPage } from "./pages/DocumentsPage";
import { AdminConversationsPage } from "./pages/admin/AdminConversationsPage";
import { AdminRestoreRequestsPage } from "./pages/admin/AdminRestoreRequestsPage";
import { AdminAuditLogPage } from "./pages/admin/AdminAuditLogPage";

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route
              path="/login"
              element={
                <RedirectIfAuthed>
                  <LoginPage />
                </RedirectIfAuthed>
              }
            />
            <Route
              path="/register"
              element={
                <RedirectIfAuthed>
                  <RegisterPage />
                </RedirectIfAuthed>
              }
            />

            <Route element={<RequireAuth />}>
              <Route path="/app" element={<UserLayout />}>
                <Route index element={<OverviewPage />} />
                <Route path="chats" element={<ChatsListPage />} />
                <Route path="chats/new" element={<ChatRoute />} />
                <Route path="chats/:conversationId" element={<ChatRoute />} />
                <Route path="deleted" element={<DeletedChatsPage />} />
                <Route path="profile" element={<ProfilePage />} />
                <Route path="settings" element={<SettingsPage />} />
              </Route>

              <Route element={<RequireAdmin />}>
                <Route path="/admin" element={<AdminLayout />}>
                  <Route index element={<AdminOverviewPage />} />
                  <Route path="users" element={<AdminUsersPage />} />
                  <Route path="documents" element={<DocumentsPage />} />
                  <Route path="conversations" element={<AdminConversationsPage />} />
                  <Route path="restore-requests" element={<AdminRestoreRequestsPage />} />
                  <Route path="audit-log" element={<AdminAuditLogPage />} />
                </Route>
              </Route>
            </Route>

            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ToastProvider>
  );
}
