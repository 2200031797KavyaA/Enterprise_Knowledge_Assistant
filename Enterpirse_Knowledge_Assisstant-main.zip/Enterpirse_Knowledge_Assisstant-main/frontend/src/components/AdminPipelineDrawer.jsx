import { useEffect, useState } from "react";
import { X, Clock, ArrowRight, ChevronDown, ChevronUp, Zap } from "lucide-react";
import { Badge } from "./Badge";
import { adminService } from "../services/adminService";
import { useToast } from "../context/ToastContext";

const STAGE_LABELS = {
  query_rewrite_ms: "Query rewrite",
  retrieval_ms: "Retrieval",
  rerank_ms: "Rerank",
  generation_ms: "Answer generation",
};
const STAGE_ORDER = ["query_rewrite_ms", "retrieval_ms", "rerank_ms", "generation_ms"];
const STAGE_COLOR = {
  query_rewrite_ms: "bg-teal-500",
  retrieval_ms: "bg-amber-500",
  rerank_ms: "bg-coral-500",
  generation_ms: "bg-paper-300",
};

/** Full-screen overlay: shows every message in a conversation, and - for
 * each assistant answer - the complete pipeline trace that produced it
 * (query rewriting, hybrid retrieval, reranking, timings, final prompt).
 * Reads the debug_trace that was captured and persisted at answer time, so
 * this reflects exactly what happened for that specific historical query. */
export function AdminPipelineDrawer({ conversation, onClose }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(() => new Set());
  const toast = useToast();

  useEffect(() => {
    if (!conversation) return;
    setLoading(true);
    adminService
      .getConversationMessages(conversation.id)
      .then((msgs) => {
        setMessages(msgs);
        // Auto-expand the trace for the most recent assistant message.
        const lastAssistant = [...msgs].reverse().find((m) => m.role === "assistant" && m.debug);
        if (lastAssistant) setExpanded(new Set([lastAssistant.id]));
      })
      .catch((e) => toast.push(e.message, "error"))
      .finally(() => setLoading(false));
  }, [conversation]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!conversation) return null;

  const toggle = (id) =>
    setExpanded((s) => {
      const next = new Set(s);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/60 px-4 py-6">
      <div className="animate-rise-in flex h-full w-full max-w-4xl flex-col overflow-hidden rounded-xl2 border border-ink-600 bg-ink-900 shadow-card">
        <div className="flex items-center justify-between border-b border-ink-600 px-5 py-4">
          <div className="min-w-0">
            <h3 className="truncate font-display text-base text-paper-100">{conversation.title}</h3>
            <p className="mt-0.5 text-xs text-paper-500">
              {conversation.owner_email || "Unknown owner"} · {new Date(conversation.created_at).toLocaleString()}
            </p>
          </div>
          <button onClick={onClose} className="shrink-0 rounded-lg p-1.5 text-paper-500 hover:bg-ink-700 hover:text-paper-100">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5">
          {loading && <p className="text-sm text-paper-500">Loading pipeline history...</p>}
          {!loading && messages.length === 0 && (
            <p className="text-sm text-paper-500">No messages in this conversation yet.</p>
          )}

          <div className="space-y-4">
            {messages.map((m) =>
              m.role === "user" ? (
                <div key={m.id} className="flex justify-end">
                  <div className="max-w-[80%] rounded-2xl rounded-tr-sm bg-amber-500 px-4 py-2.5 text-sm font-medium text-ink-950">
                    {m.content}
                  </div>
                </div>
              ) : (
                <div key={m.id} className="max-w-[95%] space-y-2">
                  <div className="rounded-2xl rounded-tl-sm border border-ink-600 bg-ink-800 px-4 py-3 text-sm leading-relaxed text-paper-100 whitespace-pre-wrap">
                    {m.content}
                  </div>

                  {m.debug ? (
                    <>
                      <button
                        onClick={() => toggle(m.id)}
                        className="flex items-center gap-1.5 rounded-lg border border-ink-600 px-2.5 py-1.5 text-xs text-paper-300 hover:border-amber-500/50 hover:text-amber-400 transition-colors"
                      >
                        <Zap size={12} />
                        {expanded.has(m.id) ? "Hide pipeline trace" : "View pipeline trace"}
                        {expanded.has(m.id) ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                        {m.debug.timings_ms?.total_ms != null && (
                          <span className="ml-1 flex items-center gap-1 text-paper-500">
                            <Clock size={11} /> {m.debug.timings_ms.total_ms} ms
                          </span>
                        )}
                      </button>
                      {expanded.has(m.id) && <PipelineTrace debug={m.debug} />}
                    </>
                  ) : (
                    <p className="pl-1 text-[11px] text-paper-500">No pipeline trace recorded for this message.</p>
                  )}
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function PipelineTrace({ debug }) {
  const timings = debug.timings_ms || {};
  const totalMs = timings.total_ms || Object.values(timings).reduce((a, b) => a + b, 0) || 1;

  return (
    <div className="animate-rise-in rounded-xl2 border border-ink-600 bg-ink-800/60 p-4 space-y-5">
      {/* Query rewriting step */}
      <div>
        <p className="mb-1.5 text-[11px] uppercase tracking-wide text-paper-500">Query rewriting</p>
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-ink-600 bg-ink-950 px-3 py-2 font-mono text-xs text-paper-300">
          <span className="truncate">{debug.original_query}</span>
          <ArrowRight size={12} className="shrink-0 text-paper-500" />
          <span className="truncate text-paper-100">{debug.improved_query}</span>
          {debug.query_rewritten ? (
            <Badge tone="teal">rewritten</Badge>
          ) : (
            <Badge>unchanged</Badge>
          )}
        </div>
      </div>

      {/* Timing breakdown */}
      {Object.keys(timings).length > 0 && (
        <div>
          <p className="mb-1.5 text-[11px] uppercase tracking-wide text-paper-500">
            Stage timings {debug.processed_at && `· processed ${new Date(debug.processed_at).toLocaleString()}`}
          </p>
          <div className="space-y-1.5">
            {STAGE_ORDER.filter((k) => timings[k] != null).map((k) => (
              <div key={k} className="flex items-center gap-2 text-xs">
                <span className="w-32 shrink-0 text-paper-300">{STAGE_LABELS[k]}</span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-950">
                  <div
                    className={`h-full rounded-full ${STAGE_COLOR[k]}`}
                    style={{ width: `${Math.max(2, (timings[k] / totalMs) * 100)}%` }}
                  />
                </div>
                <span className="w-14 shrink-0 text-right font-mono text-paper-500">{timings[k]} ms</span>
              </div>
            ))}
            <div className="flex items-center justify-between border-t border-ink-700 pt-1.5 text-xs">
              <span className="text-paper-300">Total</span>
              <span className="font-mono text-paper-100">{timings.total_ms} ms</span>
            </div>
          </div>
        </div>
      )}

      {/* Backends used */}
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone="teal">{debug.retrieval_mode}</Badge>
        <Badge tone={debug.embedding_backend === "nvidia" ? "teal" : "amber"}>embed: {debug.embedding_backend}</Badge>
        <Badge tone={debug.rerank_backend === "nvidia" ? "teal" : "amber"}>rerank: {debug.rerank_backend}</Badge>
        <Badge tone={debug.llm_backend === "key_gateway" ? "teal" : "amber"}>llm: {debug.llm_backend}</Badge>
      </div>

      {/* Retrieved candidates */}
      <div>
        <p className="mb-2 text-[11px] uppercase tracking-wide text-paper-500">
          Retrieved candidates ({debug.retrieved_chunks.length})
        </p>
        <div className="space-y-1.5">
          {debug.retrieved_chunks.map((c) => (
            <div
              key={c.chunk_id}
              className={`rounded-lg border px-3 py-2 ${
                c.used_in_context ? "border-amber-500/40 bg-amber-500/5" : "border-ink-600 bg-ink-950/40"
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-xs text-paper-100">
                  {c.filename}
                  {c.section ? ` - ${c.section}` : ""}
                </span>
                {c.used_in_context && <Badge tone="amber">used</Badge>}
              </div>
              <div className="mt-1 grid grid-cols-3 gap-2 font-mono text-[10px] text-paper-500">
                <span>BM25 {c.bm25_score.toFixed(2)}</span>
                <span>Vector {c.vector_score.toFixed(2)}</span>
                <span>Fused {c.fused_score.toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Final prompt preview */}
      <div>
        <p className="mb-1.5 text-[11px] uppercase tracking-wide text-paper-500">Final prompt context (preview)</p>
        <pre className="whitespace-pre-wrap rounded-lg border border-ink-600 bg-ink-950 p-3 font-mono text-[11px] leading-relaxed text-paper-300 max-h-40 overflow-y-auto">
          {debug.prompt_preview || "(no grounded context - answered without retrieval)"}
        </pre>
      </div>
    </div>
  );
}
