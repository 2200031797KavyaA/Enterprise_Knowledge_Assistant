/**
 * Decorative, non-interactive background for the login/register screens.
 * Two slow-drifting radial-gradient "auroras" in the amber/teal palette,
 * plus a faint constellation of connected nodes to evoke a knowledge
 * graph / document-retrieval concept. Pure CSS animation (no JS ticking),
 * and respects prefers-reduced-motion via the global rule in index.css.
 */
export function AuthBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden bg-ink-950">
      <div className="auth-aurora auth-aurora-amber" />
      <div className="auth-aurora auth-aurora-teal" />

      <svg
        className="absolute inset-0 h-full w-full opacity-[0.18]"
        viewBox="0 0 800 800"
        preserveAspectRatio="xMidYMid slice"
      >
        <g className="auth-nodes" stroke="#5FB4A2" strokeWidth="1" fill="none">
          <line x1="80" y1="120" x2="240" y2="200" />
          <line x1="240" y1="200" x2="200" y2="360" />
          <line x1="240" y1="200" x2="420" y2="150" />
          <line x1="420" y1="150" x2="600" y2="240" />
          <line x1="600" y1="240" x2="720" y2="140" />
          <line x1="200" y1="360" x2="360" y2="440" />
          <line x1="360" y1="440" x2="560" y2="420" />
          <line x1="560" y1="420" x2="700" y2="520" />
          <line x1="360" y1="440" x2="300" y2="600" />
          <line x1="300" y1="600" x2="480" y2="680" />
          <line x1="480" y1="680" x2="640" y2="640" />
          <line x1="120" y1="520" x2="300" y2="600" />
        </g>
        <g className="auth-nodes" fill="#E8A33D">
          {[
            [80, 120], [240, 200], [420, 150], [600, 240], [720, 140],
            [200, 360], [360, 440], [560, 420], [700, 520], [300, 600],
            [480, 680], [640, 640], [120, 520],
          ].map(([cx, cy], i) => (
            <circle key={i} cx={cx} cy={cy} r={i % 3 === 0 ? 4 : 2.5} />
          ))}
        </g>
      </svg>

      <style>{`
        .auth-aurora {
          position: absolute;
          width: 60vmax;
          height: 60vmax;
          border-radius: 9999px;
          filter: blur(90px);
          opacity: 0.28;
          animation: auth-drift 22s ease-in-out infinite;
        }
        .auth-aurora-amber {
          background: radial-gradient(circle, #E8A33D 0%, transparent 70%);
          top: -20%;
          left: -10%;
          animation-delay: 0s;
        }
        .auth-aurora-teal {
          background: radial-gradient(circle, #5FB4A2 0%, transparent 70%);
          bottom: -25%;
          right: -10%;
          animation-delay: -11s;
        }
        @keyframes auth-drift {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(4%, 6%) scale(1.06); }
          66% { transform: translate(-3%, -4%) scale(0.97); }
        }
        .auth-nodes circle {
          animation: auth-pulse 3.6s ease-in-out infinite;
        }
        @keyframes auth-pulse {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }
        @media (prefers-reduced-motion: reduce) {
          .auth-aurora, .auth-nodes circle { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
