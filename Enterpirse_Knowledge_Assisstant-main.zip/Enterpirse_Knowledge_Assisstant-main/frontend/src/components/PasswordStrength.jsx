import { Check, X } from "lucide-react";

const RULES = [
  { key: "min_length", label: "At least 8 characters", test: (p) => p.length >= 8 },
  { key: "uppercase", label: "One uppercase letter", test: (p) => /[A-Z]/.test(p) },
  { key: "lowercase", label: "One lowercase letter", test: (p) => /[a-z]/.test(p) },
  { key: "number", label: "One number", test: (p) => /\d/.test(p) },
  { key: "special", label: "One special character", test: (p) => /[^A-Za-z0-9]/.test(p) },
];

export function isPasswordStrong(password) {
  return RULES.every((r) => r.test(password));
}

export function PasswordStrength({ password }) {
  return (
    <div className="grid grid-cols-1 gap-1 rounded-lg border border-ink-600 bg-ink-800/60 px-3 py-2.5 sm:grid-cols-2">
      {RULES.map((r) => {
        const satisfied = r.test(password || "");
        return (
          <div key={r.key} className={`flex items-center gap-1.5 text-xs ${satisfied ? "text-teal-400" : "text-paper-500"}`}>
            {satisfied ? <Check size={12} /> : <X size={12} />}
            {r.label}
          </div>
        );
      })}
    </div>
  );
}
