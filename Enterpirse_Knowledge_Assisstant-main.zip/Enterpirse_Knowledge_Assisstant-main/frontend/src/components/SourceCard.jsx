import { FileText } from "lucide-react";

/**
 * Signature element: sources render as small catalog-card citations, echoing
 * how the underlying documents are physical policy handbooks being indexed.
 *
 * User-facing only: shows filename/section/relevance. Never the retrieved
 * chunk text itself - the API doesn't send it here by design (admins get
 * full excerpts through the RAG trace panel instead).
 */
export function SourceCard({ index, source }) {
  return (
    <div className="relative rounded-lg border border-ink-600 bg-ink-800/60 overflow-hidden">
      <div className="absolute -top-2 -left-2 flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-[11px] font-mono font-semibold text-ink-950">
        {index}
      </div>
      <div className="flex w-full items-center justify-between gap-2 px-3 pl-6 py-2.5">
        <div className="flex items-center gap-2 min-w-0">
          <FileText size={13} className="text-paper-500 shrink-0" />
          <span className="truncate text-sm text-paper-100">{source.filename}</span>
          {source.section && <span className="hidden sm:inline truncate text-xs text-paper-500">- {source.section}</span>}
        </div>
        <span className="font-mono text-[11px] text-teal-400 shrink-0">{(source.similarity * 100).toFixed(0)}%</span>
      </div>
    </div>
  );
}
