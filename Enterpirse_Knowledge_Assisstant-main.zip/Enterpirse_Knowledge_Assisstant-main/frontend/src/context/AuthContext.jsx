import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { authService } from "../services/authService";
import { tokenStore, setUnauthorizedHandler } from "../services/apiClient";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const clearSession = useCallback(() => {
    tokenStore.clear();
    setUser(null);
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(clearSession);
  }, [clearSession]);

  useEffect(() => {
    if (!tokenStore.get()) {
      setLoading(false);
      return;
    }
    authService
      .me()
      .then(setUser)
      .catch(() => tokenStore.clear())
      .finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    const res = await authService.login(email, password);
    tokenStore.set(res.access_token);
    setUser(res.user);
    return res.user;
  };

  const register = async (name, email, password, confirmPassword) => {
    const res = await authService.register(name, email, password, confirmPassword);
    tokenStore.set(res.access_token);
    setUser(res.user);
    return res.user;
  };

  const logout = () => {
    clearSession();
  };

  const refreshUser = async () => {
    const me = await authService.me();
    setUser(me);
    return me;
  };

  return (
    <AuthCtx.Provider value={{ user, loading, login, register, logout, refreshUser }}>{children}</AuthCtx.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
