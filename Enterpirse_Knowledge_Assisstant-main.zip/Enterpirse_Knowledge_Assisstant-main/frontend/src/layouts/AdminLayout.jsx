import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  ShieldCheck,
  LayoutDashboard,
  Users,
  Library,
  MessagesSquare,
  History,
  ScrollText,
  LogOut,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

const navItem = "flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors";

const LINKS = [
  { to: "/admin", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/documents", label: "Documents", icon: Library },
  { to: "/admin/conversations", label: "Conversations", icon: MessagesSquare },
  { to: "/admin/restore-requests", label: "Restore Requests", icon: History },
  { to: "/admin/audit-log", label: "Audit Log", icon: ScrollText },
];

export function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-ink-950">
      <aside className="flex h-full w-64 shrink-0 flex-col border-r border-ink-600 bg-ink-950">
        <div className="flex items-center gap-2 px-4 py-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500">
            <ShieldCheck size={16} className="text-ink-950" />
          </div>
          <div className="min-w-0">
            <p className="font-display text-sm leading-tight text-paper-100">Admin Control Center</p>
            <p className="text-[10px] font-mono text-paper-500 truncate">{user?.name}</p>
          </div>
        </div>

        <nav className="px-3 space-y-1">
          {LINKS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) => `${navItem} ${isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"}`}
            >
              <Icon size={15} /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto border-t border-ink-600 px-3 py-3">
          <NavLink to="/app" className="mb-1 flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-paper-500 hover:bg-ink-800 hover:text-paper-100 transition-colors">
            Switch to user view
          </NavLink>
          <button
            onClick={() => {
              logout();
              navigate("/login", { replace: true });
            }}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-paper-300 hover:bg-ink-800 hover:text-coral-500 transition-colors"
          >
            <LogOut size={15} /> Log out
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}
