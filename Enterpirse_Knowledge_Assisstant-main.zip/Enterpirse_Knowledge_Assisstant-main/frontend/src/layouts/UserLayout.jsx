import { useCallback, useEffect, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  BookOpenText,
  LayoutDashboard,
  MessagesSquare,
  MessageSquarePlus,
  Trash2,
  User as UserIcon,
  Settings as SettingsIcon,
  LogOut,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { chatService } from "../services/chatService";
import { useToast } from "../context/ToastContext";

const navItem = "flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors";

export function UserLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [conversations, setConversations] = useState([]);

  const loadConversations = useCallback(async () => {
    try {
      setConversations(await chatService.listConversations());
    } catch {
      // best-effort - chat still works without a sidebar list
    }
  }, []);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  const handleDeleteConversation = async (id, e) => {
    e.stopPropagation();
    e.preventDefault();
    try {
      await chatService.deleteConversation(id);
      loadConversations();
      toast.push("Conversation moved to deleted - request restoration anytime from Deleted Chats");
      navigate("/app/chats");
    } catch (err) {
      toast.push(err.message, "error");
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-ink-950">
      <aside className="flex h-full w-64 shrink-0 flex-col border-r border-ink-600 bg-ink-950">
        <div className="flex items-center gap-2 px-4 py-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500">
            <BookOpenText size={16} className="text-ink-950" />
          </div>
          <div className="min-w-0">
            <p className="font-display text-sm leading-tight text-paper-100 truncate">Knowledge Assistant</p>
            <p className="text-[10px] font-mono text-paper-500">{user?.name}</p>
          </div>
        </div>

        <nav className="px-3 space-y-1">
          <NavLink to="/app/chats/new" className="flex w-full items-center gap-2 rounded-lg bg-amber-500 px-3 py-2 text-sm font-medium text-ink-950 hover:bg-amber-400 transition-colors">
            <MessageSquarePlus size={15} /> New chat
          </NavLink>
          <NavLink to="/app" end className={({ isActive }) => `${navItem} ${isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"}`}>
            <LayoutDashboard size={15} /> Overview
          </NavLink>
          <NavLink to="/app/chats" className={({ isActive }) => `${navItem} ${isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"}`}>
            <MessagesSquare size={15} /> My Chats
          </NavLink>
          <NavLink to="/app/deleted" className={({ isActive }) => `${navItem} ${isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"}`}>
            <Trash2 size={15} /> Deleted Chats
          </NavLink>
          <NavLink to="/app/profile" className={({ isActive }) => `${navItem} ${isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"}`}>
            <UserIcon size={15} /> Profile
          </NavLink>
          <NavLink to="/app/settings" className={({ isActive }) => `${navItem} ${isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"}`}>
            <SettingsIcon size={15} /> Settings
          </NavLink>
        </nav>

        <div className="mt-4 flex-1 overflow-y-auto px-3">
          <p className="px-1 pb-2 text-[11px] uppercase tracking-wide text-paper-500">Conversations</p>
          <div className="space-y-0.5">
            {conversations.length === 0 && <p className="px-1 py-2 text-xs text-paper-500">No conversations yet.</p>}
            {conversations.map((c) => (
              <NavLink
                key={c.id}
                to={`/app/chats/${c.id}`}
                className={({ isActive }) =>
                  `group flex items-center gap-2 rounded-lg px-2 py-2 transition-colors ${
                    isActive ? "bg-ink-700 text-paper-100" : "text-paper-300 hover:bg-ink-800"
                  }`
                }
              >
                <MessagesSquare size={13} className="shrink-0 text-paper-500" />
                <span className="truncate text-xs flex-1">{c.title}</span>
                <button onClick={(e) => handleDeleteConversation(c.id, e)} className="opacity-0 group-hover:opacity-100 text-paper-500 hover:text-coral-500 transition-opacity">
                  <Trash2 size={12} />
                </button>
              </NavLink>
            ))}
          </div>
        </div>

        <div className="border-t border-ink-600 px-3 py-3">
          <button
            onClick={() => {
              logout();
              navigate("/login", { replace: true });
            }}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-paper-300 hover:bg-ink-800 hover:text-coral-500 transition-colors"
          >
            <LogOut size={15} /> Log out
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-hidden">
        <Outlet context={{ conversations, refreshConversations: loadConversations }} />
      </main>
    </div>
  );
}
