import { useEffect, useState } from "react";
import { ScrollText } from "lucide-react";
import { adminService } from "../../services/adminService";
import { useToast } from "../../context/ToastContext";
import { Badge } from "../../components/Badge";
import { EmptyState } from "../../components/EmptyState";

export function AdminAuditLogPage() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  useEffect(() => {
    adminService
      .auditLogs()
      .then(setLogs)
      .catch((e) => toast.push(e.message, "error"))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="mx-auto max-w-4xl px-8 py-10">
      <h1 className="font-display text-2xl text-paper-100">Audit Log</h1>
      <p className="mt-1 text-sm text-paper-500">A record of security-relevant actions across the system.</p>

      <div className="mt-6">
        {!loading && logs.length === 0 ? (
          <EmptyState icon={ScrollText} title="No activity yet" description="Actions like logins, deletions, and role changes will show up here." />
        ) : (
          <div className="space-y-1.5">
            {logs.map((l) => (
              <div key={l.id} className="flex items-center gap-3 rounded-lg border border-ink-700 bg-ink-800/60 px-4 py-2.5 text-sm">
                <Badge tone={l.status === "success" ? "teal" : "coral"}>{l.action}</Badge>
                <span className="flex-1 truncate text-paper-300">{l.actor_email || "system"}</span>
                {l.target_type && <span className="text-xs text-paper-500">{l.target_type}</span>}
                <span className="shrink-0 text-xs text-paper-500">{new Date(l.created_at).toLocaleString()}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
