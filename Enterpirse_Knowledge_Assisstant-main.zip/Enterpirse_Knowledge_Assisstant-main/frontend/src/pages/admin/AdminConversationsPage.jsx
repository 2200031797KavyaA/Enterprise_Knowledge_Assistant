import { useEffect, useState } from "react";
import { MessagesSquare, RotateCcw, Trash2, Eye } from "lucide-react";
import { adminService } from "../../services/adminService";
import { useToast } from "../../context/ToastContext";
import { Badge } from "../../components/Badge";
import { AdminPipelineDrawer } from "../../components/AdminPipelineDrawer";

export function AdminConversationsPage() {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all"); // all | active | deleted
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [viewing, setViewing] = useState(null);
  const toast = useToast();

  const load = () => {
    setLoading(true);
    adminService
      .listAllConversations(true)
      .then(setConversations)
      .catch((e) => toast.push(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = conversations.filter((c) => {
    if (filter === "active") return !c.is_deleted;
    if (filter === "deleted") return c.is_deleted;
    return true;
  });

  const restore = async (id) => {
    try {
      await adminService.restoreConversation(id);
      toast.push("Conversation restored");
      load();
    } catch (err) {
      toast.push(err.message, "error");
    }
  };

  const permanentlyDelete = async () => {
    try {
      await adminService.permanentlyDeleteConversation(confirmDelete.id);
      toast.push("Conversation permanently deleted");
      load();
    } catch (err) {
      toast.push(err.message, "error");
    } finally {
      setConfirmDelete(null);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-8 py-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl text-paper-100">Conversations</h1>
          <p className="mt-1 text-sm text-paper-500">All conversations across every user, including soft-deleted ones.</p>
        </div>
        <div className="flex gap-1 rounded-lg border border-ink-600 bg-ink-800 p-1">
          {["all", "active", "deleted"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-md px-3 py-1.5 text-xs capitalize transition-colors ${
                filter === f ? "bg-ink-700 text-paper-100" : "text-paper-500 hover:text-paper-300"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl2 border border-ink-600 bg-ink-800 shadow-card">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-ink-600 text-xs uppercase tracking-wide text-paper-500">
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Owner</th>
              <th className="px-4 py-3 font-medium">Created</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {!loading && filtered.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-paper-500">
                  No conversations match this filter.
                </td>
              </tr>
            )}
            {filtered.map((c) => (
              <tr key={c.id} className="border-b border-ink-700 last:border-0 hover:bg-ink-700/20 transition-colors">
                <td className="px-4 py-3 text-paper-100">
                  <button onClick={() => setViewing(c)} className="flex items-center gap-2 text-left hover:text-amber-400 transition-colors">
                    <MessagesSquare size={13} className="text-paper-500" />
                    {c.title}
                  </button>
                </td>
                <td className="px-4 py-3 text-paper-300">{c.owner_email || "-"}</td>
                <td className="px-4 py-3 text-paper-500">{new Date(c.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  {c.is_deleted ? <Badge tone="coral">Deleted {c.deleted_at ? new Date(c.deleted_at).toLocaleDateString() : ""}</Badge> : <Badge tone="teal">Active</Badge>}
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => setViewing(c)} className="flex items-center gap-1 rounded-lg border border-ink-600 px-2 py-1 text-xs text-paper-300 hover:border-amber-500/50 hover:text-amber-400 transition-colors">
                      <Eye size={12} /> View pipeline
                    </button>
                    {c.is_deleted && (
                      <button onClick={() => restore(c.id)} className="flex items-center gap-1 rounded-lg border border-ink-600 px-2 py-1 text-xs text-paper-300 hover:border-teal-400 hover:text-teal-400 transition-colors">
                        <RotateCcw size={12} /> Restore
                      </button>
                    )}
                    <button onClick={() => setConfirmDelete(c)} className="flex items-center gap-1 rounded-lg border border-ink-600 px-2 py-1 text-xs text-paper-300 hover:border-coral-500 hover:text-coral-500 transition-colors">
                      <Trash2 size={12} /> Delete permanently
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {confirmDelete && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-sm rounded-xl2 border border-ink-600 bg-ink-800 p-5 shadow-card">
            <p className="text-sm font-medium text-paper-100">Permanently delete this conversation?</p>
            <p className="mt-2 text-sm text-paper-500">This can't be undone. "{confirmDelete.title}" and its messages will be gone for good.</p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setConfirmDelete(null)} className="rounded-lg px-3 py-2 text-sm text-paper-300 hover:bg-ink-700 transition-colors">
                Cancel
              </button>
              <button onClick={permanentlyDelete} className="rounded-lg bg-coral-500 px-3 py-2 text-sm font-medium text-ink-950 hover:opacity-90 transition-colors">
                Delete permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {viewing && <AdminPipelineDrawer conversation={viewing} onClose={() => setViewing(null)} />}
    </div>
  );
}
