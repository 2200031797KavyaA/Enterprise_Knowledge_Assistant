import { useEffect, useState } from "react";
import { Users, MessagesSquare, FileText, ThumbsUp, ThumbsDown, Trash2, History } from "lucide-react";
import { adminService } from "../../services/adminService";
import { useToast } from "../../context/ToastContext";

const CARDS = [
  { key: "total_users", label: "Total users", icon: Users, tone: "text-amber-400" },
  { key: "active_users", label: "Active users", icon: Users, tone: "text-teal-400" },
  { key: "total_conversations", label: "Conversations", icon: MessagesSquare, tone: "text-amber-400" },
  { key: "deleted_conversations", label: "Deleted conversations", icon: Trash2, tone: "text-coral-500" },
  { key: "total_documents", label: "Documents indexed", icon: FileText, tone: "text-amber-400" },
  { key: "positive_feedback", label: "Positive feedback", icon: ThumbsUp, tone: "text-teal-400" },
  { key: "negative_feedback", label: "Negative feedback", icon: ThumbsDown, tone: "text-coral-500" },
  { key: "pending_restore_requests", label: "Pending restore requests", icon: History, tone: "text-amber-400" },
];

export function AdminOverviewPage() {
  const [data, setData] = useState(null);
  const toast = useToast();

  useEffect(() => {
    adminService
      .analyticsOverview()
      .then(setData)
      .catch((e) => toast.push(e.message, "error"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="mx-auto max-w-5xl px-8 py-10">
      <h1 className="font-display text-2xl text-paper-100">Overview</h1>
      <p className="mt-1 text-sm text-paper-500">Real-time counts from the database - nothing here is simulated.</p>

      {!data ? (
        <p className="mt-8 text-sm text-paper-500">Loading analytics...</p>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {CARDS.map(({ key, label, icon: Icon, tone }) => (
            <div key={key} className="rounded-xl2 border border-ink-600 bg-ink-800 p-5 shadow-card">
              <Icon size={16} className={tone} />
              <p className="mt-3 font-display text-2xl text-paper-100">{data[key]}</p>
              <p className="mt-1 text-xs text-paper-500">{label}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
