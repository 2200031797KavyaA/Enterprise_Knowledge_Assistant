import { useEffect, useState } from "react";
import { History, Check, X } from "lucide-react";
import { adminService } from "../../services/adminService";
import { useToast } from "../../context/ToastContext";
import { Badge } from "../../components/Badge";
import { EmptyState } from "../../components/EmptyState";

const TONE = { PENDING: "amber", APPROVED: "teal", REJECTED: "coral" };

export function AdminRestoreRequestsPage() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [decision, setDecision] = useState(null); // { request, approve }
  const [note, setNote] = useState("");
  const toast = useToast();

  const load = () => {
    setLoading(true);
    adminService
      .listRestoreRequests()
      .then(setRequests)
      .catch((e) => toast.push(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const resolve = async () => {
    try {
      await adminService.resolveRestoreRequest(decision.request.id, decision.approve, note);
      toast.push(decision.approve ? "Request approved and conversation restored" : "Request rejected");
      load();
    } catch (err) {
      toast.push(err.message, "error");
    } finally {
      setDecision(null);
      setNote("");
    }
  };

  const pending = requests.filter((r) => r.status === "PENDING");
  const resolved = requests.filter((r) => r.status !== "PENDING");

  return (
    <div className="mx-auto max-w-4xl px-8 py-10">
      <h1 className="font-display text-2xl text-paper-100">Restore Requests</h1>
      <p className="mt-1 text-sm text-paper-500">Users request restoration of deleted conversations here for your review.</p>

      <div className="mt-6">
        <p className="mb-3 text-xs uppercase tracking-wide text-paper-500">Pending</p>
        {!loading && pending.length === 0 ? (
          <EmptyState icon={History} title="No restoration requests" description="No requests are pending at the moment." />
        ) : (
          <div className="space-y-3">
            {pending.map((r) => (
              <div key={r.id} className="rounded-xl2 border border-ink-600 bg-ink-800 p-4 shadow-card">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-paper-100">{r.conversation_title || "Conversation"}</p>
                  <Badge tone={TONE[r.status]}>{r.status}</Badge>
                </div>
                <p className="mt-2 text-sm text-paper-300">"{r.reason}"</p>
                <p className="mt-1 text-xs text-paper-500">Requested {new Date(r.requested_at).toLocaleString()}</p>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => setDecision({ request: r, approve: true })} className="flex items-center gap-1 rounded-lg border border-teal-400/40 px-3 py-1.5 text-xs text-teal-400 hover:bg-teal-400/10 transition-colors">
                    <Check size={12} /> Approve
                  </button>
                  <button onClick={() => setDecision({ request: r, approve: false })} className="flex items-center gap-1 rounded-lg border border-coral-500/40 px-3 py-1.5 text-xs text-coral-500 hover:bg-coral-500/10 transition-colors">
                    <X size={12} /> Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {resolved.length > 0 && (
        <div className="mt-10">
          <p className="mb-3 text-xs uppercase tracking-wide text-paper-500">Resolved</p>
          <div className="space-y-2">
            {resolved.map((r) => (
              <div key={r.id} className="flex items-center gap-3 rounded-lg border border-ink-700 bg-ink-800/60 px-4 py-3">
                <span className="flex-1 truncate text-sm text-paper-300">{r.conversation_title || "Conversation"}</span>
                <Badge tone={TONE[r.status]}>{r.status}</Badge>
                <span className="text-xs text-paper-500">{r.resolved_at ? new Date(r.resolved_at).toLocaleDateString() : ""}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {decision && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-sm rounded-xl2 border border-ink-600 bg-ink-800 p-5 shadow-card">
            <p className="text-sm font-medium text-paper-100">{decision.approve ? "Approve" : "Reject"} this request?</p>
            <textarea
              rows={2}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional note for the user..."
              className="mt-3 w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
            />
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setDecision(null)} className="rounded-lg px-3 py-2 text-sm text-paper-300 hover:bg-ink-700 transition-colors">
                Cancel
              </button>
              <button onClick={resolve} className="rounded-lg bg-amber-500 px-3 py-2 text-sm font-medium text-ink-950 hover:bg-amber-400 transition-colors">
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
