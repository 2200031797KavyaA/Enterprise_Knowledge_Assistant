import { useEffect, useState } from "react";
import { ShieldCheck, ShieldOff, UserCog } from "lucide-react";
import { adminService } from "../../services/adminService";
import { useToast } from "../../context/ToastContext";
import { useAuth } from "../../context/AuthContext";
import { Badge } from "../../components/Badge";

export function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [confirmTarget, setConfirmTarget] = useState(null); // { user, action }
  const toast = useToast();
  const { user: me } = useAuth();

  const load = () => {
    setLoading(true);
    adminService
      .listUsers()
      .then(setUsers)
      .catch((e) => toast.push(e.message, "error"))
      .finally(() => setLoading(false));
  };

  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const runAction = async () => {
    const { user, action } = confirmTarget;
    try {
      if (action === "toggle-active") await adminService.setUserActive(user.id, !user.is_active);
      if (action === "toggle-role") await adminService.setUserRole(user.id, user.role === "ADMIN" ? "USER" : "ADMIN");
      toast.push("User updated");
      load();
    } catch (err) {
      toast.push(err.message, "error");
    } finally {
      setConfirmTarget(null);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-8 py-10">
      <h1 className="font-display text-2xl text-paper-100">Users</h1>
      <p className="mt-1 text-sm text-paper-500">Manage accounts, roles, and access.</p>

      <div className="mt-6 overflow-x-auto rounded-xl2 border border-ink-600 bg-ink-800 shadow-card">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-ink-600 text-xs uppercase tracking-wide text-paper-500">
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3 font-medium">Last login</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {!loading && users.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-paper-500">
                  No users yet.
                </td>
              </tr>
            )}
            {users.map((u) => (
              <tr key={u.id} className="border-b border-ink-700 last:border-0">
                <td className="px-4 py-3 text-paper-100">{u.name}</td>
                <td className="px-4 py-3 text-paper-300">{u.email}</td>
                <td className="px-4 py-3">
                  <Badge tone={u.role === "ADMIN" ? "teal" : "neutral"}>{u.role}</Badge>
                </td>
                <td className="px-4 py-3">
                  <Badge tone={u.is_active ? "teal" : "coral"}>{u.is_active ? "Active" : "Deactivated"}</Badge>
                </td>
                <td className="px-4 py-3 text-paper-500">{new Date(u.created_at).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-paper-500">{u.last_login_at ? new Date(u.last_login_at).toLocaleDateString() : "-"}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <button
                      disabled={u.id === me.id}
                      onClick={() => setConfirmTarget({ user: u, action: "toggle-role" })}
                      className="flex items-center gap-1 rounded-lg border border-ink-600 px-2 py-1 text-xs text-paper-300 hover:border-amber-500 hover:text-amber-400 disabled:opacity-30 transition-colors"
                    >
                      <UserCog size={12} /> {u.role === "ADMIN" ? "Make user" : "Make admin"}
                    </button>
                    <button
                      disabled={u.id === me.id}
                      onClick={() => setConfirmTarget({ user: u, action: "toggle-active" })}
                      className="flex items-center gap-1 rounded-lg border border-ink-600 px-2 py-1 text-xs text-paper-300 hover:border-coral-500 hover:text-coral-500 disabled:opacity-30 transition-colors"
                    >
                      {u.is_active ? <ShieldOff size={12} /> : <ShieldCheck size={12} />} {u.is_active ? "Deactivate" : "Activate"}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {confirmTarget && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/50 px-4">
          <div className="w-full max-w-sm rounded-xl2 border border-ink-600 bg-ink-800 p-5 shadow-card">
            <p className="text-sm font-medium text-paper-100">Confirm action</p>
            <p className="mt-2 text-sm text-paper-300">
              {confirmTarget.action === "toggle-role"
                ? `Change ${confirmTarget.user.name}'s role to ${confirmTarget.user.role === "ADMIN" ? "USER" : "ADMIN"}?`
                : `${confirmTarget.user.is_active ? "Deactivate" : "Activate"} ${confirmTarget.user.name}'s account?`}
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setConfirmTarget(null)} className="rounded-lg px-3 py-2 text-sm text-paper-300 hover:bg-ink-700 transition-colors">
                Cancel
              </button>
              <button onClick={runAction} className="rounded-lg bg-amber-500 px-3 py-2 text-sm font-medium text-ink-950 hover:bg-amber-400 transition-colors">
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
