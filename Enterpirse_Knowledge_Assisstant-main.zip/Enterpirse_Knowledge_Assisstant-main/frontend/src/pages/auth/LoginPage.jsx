import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { BookOpenText, Eye, EyeOff, Loader2 } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { ApiError } from "../../services/apiClient";
import { AuthBackground } from "../../components/AuthBackground";

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const user = await login(email, password);
      const dest = location.state?.from?.pathname || (user.role === "ADMIN" ? "/admin" : "/app");
      navigate(dest, { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Unable to sign in right now.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4">
      <AuthBackground />
      <div className="relative z-10 w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-500 shadow-card">
              <BookOpenText size={20} className="text-ink-950" />
            </div>
            <h1 className="font-display text-xl text-paper-100 text-left">Enterprise Knowledge Assistant</h1>
          </div>
          <p className="text-sm text-paper-500">Sign in to continue</p>
        </div>

        <form onSubmit={submit} className="animate-rise-in rounded-xl2 border border-ink-600 bg-ink-800/90 backdrop-blur-sm p-6 shadow-card space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-paper-300">Email</label>
            <input
              type="email"
              required
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2.5 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
              placeholder="you@company.com"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-medium text-paper-300">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2.5 pr-10 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-paper-500 hover:text-paper-100"
              >
                {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="rounded-lg border border-coral-500/40 bg-coral-500/10 px-3 py-2 text-xs text-coral-500">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-amber-500 px-3 py-2.5 text-sm font-medium text-ink-950 hover:bg-amber-400 disabled:opacity-60 transition-colors"
          >
            {submitting && <Loader2 size={15} className="animate-spin" />}
            {submitting ? "Authenticating..." : "Sign in"}
          </button>

          <p className="text-center text-xs text-paper-500">
            Don't have an account?{" "}
            <Link to="/register" className="text-amber-400 hover:text-amber-300">
              Create one
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
