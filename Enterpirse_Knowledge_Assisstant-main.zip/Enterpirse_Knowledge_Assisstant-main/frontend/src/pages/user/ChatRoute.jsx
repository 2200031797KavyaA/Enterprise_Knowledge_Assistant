import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import { ChatPage } from "../ChatPage";

export function ChatRoute() {
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const { refreshConversations } = useOutletContext();

  return (
    <ChatPage
      key={conversationId || "new"}
      conversationId={conversationId || null}
      onConversationCreated={(id) => {
        refreshConversations();
        navigate(`/app/chats/${id}`, { replace: true });
      }}
    />
  );
}
