import { useState } from "react";
import { Link, useNavigate, useOutletContext } from "react-router-dom";
import { MessagesSquare, Search, Trash2, MessageSquarePlus } from "lucide-react";
import { chatService } from "../../services/chatService";
import { useToast } from "../../context/ToastContext";
import { EmptyState } from "../../components/EmptyState";

export function ChatsListPage() {
  const { conversations, refreshConversations } = useOutletContext();
  const [query, setQuery] = useState("");
  const toast = useToast();
  const navigate = useNavigate();

  const filtered = conversations.filter((c) => c.title.toLowerCase().includes(query.toLowerCase()));

  const handleDelete = async (id) => {
    try {
      await chatService.deleteConversation(id);
      refreshConversations();
      toast.push("Conversation moved to deleted - you can request restoration from Deleted Chats");
    } catch (err) {
      toast.push(err.message, "error");
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-paper-100">My Chats</h1>
        <button
          onClick={() => navigate("/app/chats/new")}
          className="flex items-center gap-2 rounded-lg bg-amber-500 px-3 py-2 text-sm font-medium text-ink-950 hover:bg-amber-400 transition-colors"
        >
          <MessageSquarePlus size={15} /> New chat
        </button>
      </div>

      <div className="relative mt-5">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-paper-500" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search conversations..."
          className="w-full rounded-lg border border-ink-600 bg-ink-800 py-2.5 pl-9 pr-3 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
        />
      </div>

      <div className="mt-5">
        {filtered.length === 0 ? (
          <EmptyState icon={MessagesSquare} title="No conversations" description="Start your first conversation to see it here." />
        ) : (
          <div className="space-y-2">
            {filtered.map((c) => (
              <div key={c.id} className="group flex items-center gap-3 rounded-lg border border-ink-600 bg-ink-800 px-4 py-3 hover:bg-ink-700 transition-colors">
                <MessagesSquare size={15} className="text-paper-500 shrink-0" />
                <Link to={`/app/chats/${c.id}`} className="flex-1 truncate text-sm text-paper-100">
                  {c.title}
                </Link>
                <span className="text-xs text-paper-500 shrink-0">{new Date(c.created_at).toLocaleDateString()}</span>
                <button onClick={() => handleDelete(c.id)} className="text-paper-500 hover:text-coral-500 transition-colors shrink-0">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
