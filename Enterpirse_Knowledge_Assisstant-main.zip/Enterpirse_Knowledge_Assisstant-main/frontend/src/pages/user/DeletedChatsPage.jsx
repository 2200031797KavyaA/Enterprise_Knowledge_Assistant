import { useEffect, useState } from "react";
import { Trash2, Send, Clock, CheckCircle2, XCircle, Hourglass } from "lucide-react";
import { restoreRequestService } from "../../services/restoreRequestService";
import { useToast } from "../../context/ToastContext";
import { EmptyState } from "../../components/EmptyState";
import { Badge } from "../../components/Badge";

const STATUS_META = {
  PENDING: { icon: Hourglass, tone: "text-amber-400" },
  APPROVED: { icon: CheckCircle2, tone: "text-teal-400" },
  REJECTED: { icon: XCircle, tone: "text-coral-500" },
};

export function DeletedChatsPage() {
  const [deleted, setDeleted] = useState([]);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [target, setTarget] = useState(null);
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const toast = useToast();

  const load = async () => {
    setLoading(true);
    try {
      const [d, r] = await Promise.all([restoreRequestService.listDeletedConversations(), restoreRequestService.mine()]);
      setDeleted(d);
      setRequests(r);
    } catch (err) {
      toast.push(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const requestedIds = new Set(requests.filter((r) => r.status === "PENDING").map((r) => r.conversation_id));

  const submit = async (e) => {
    e.preventDefault();
    if (!target) return;
    setSubmitting(true);
    try {
      await restoreRequestService.submit(target.id, reason);
      toast.push("Restoration request submitted to admin");
      setTarget(null);
      setReason("");
      load();
    } catch (err) {
      toast.push(err.message, "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="font-display text-2xl text-paper-100">Deleted Chats</h1>
      <p className="mt-1 text-sm text-paper-500">
        Deleted conversations aren't restored automatically. Submit a request and an admin will review it.
      </p>

      <div className="mt-6">
        {!loading && deleted.length === 0 ? (
          <EmptyState icon={Trash2} title="Nothing deleted" description="Conversations you delete will show up here." />
        ) : (
          <div className="space-y-2">
            {deleted.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-lg border border-ink-600 bg-ink-800 px-4 py-3">
                <Trash2 size={15} className="text-paper-500 shrink-0" />
                <span className="flex-1 truncate text-sm text-paper-100">{c.title}</span>
                {requestedIds.has(c.id) ? (
                  <Badge tone="amber">Request pending</Badge>
                ) : (
                  <button
                    onClick={() => setTarget(c)}
                    className="flex items-center gap-1.5 rounded-lg border border-ink-600 px-2.5 py-1.5 text-xs text-paper-300 hover:border-amber-500 hover:text-amber-400 transition-colors"
                  >
                    <Send size={12} /> Request restore
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {requests.length > 0 && (
        <div className="mt-10">
          <p className="mb-3 text-xs uppercase tracking-wide text-paper-500">My restore requests</p>
          <div className="space-y-2">
            {requests.map((r) => {
              const meta = STATUS_META[r.status];
              const Icon = meta.icon;
              return (
                <div key={r.id} className="rounded-lg border border-ink-600 bg-ink-800 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Icon size={14} className={meta.tone} />
                    <span className="flex-1 truncate text-sm text-paper-100">{r.conversation_title || "Conversation"}</span>
                    <span className="flex items-center gap-1 text-[11px] text-paper-500">
                      <Clock size={11} /> {new Date(r.requested_at).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="mt-1.5 pl-6 text-xs text-paper-500">{r.reason}</p>
                  {r.resolution_reason && <p className="mt-1 pl-6 text-xs text-paper-500 italic">Admin note: {r.resolution_reason}</p>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {target && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/50 px-4">
          <form onSubmit={submit} className="w-full max-w-sm rounded-xl2 border border-ink-600 bg-ink-800 p-5 shadow-card space-y-3">
            <p className="text-sm font-medium text-paper-100">Restore "{target.title}"</p>
            <textarea
              required
              minLength={3}
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Why do you need this conversation restored?"
              className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
            />
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setTarget(null)} className="rounded-lg px-3 py-2 text-sm text-paper-300 hover:bg-ink-700 transition-colors">
                Cancel
              </button>
              <button type="submit" disabled={submitting} className="rounded-lg bg-amber-500 px-3 py-2 text-sm font-medium text-ink-950 hover:bg-amber-400 disabled:opacity-60 transition-colors">
                {submitting ? "Submitting..." : "Submit request"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
