import { useOutletContext, Link } from "react-router-dom";
import { MessagesSquare, MessageSquarePlus, Clock } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

export function OverviewPage() {
  const { user } = useAuth();
  const { conversations } = useOutletContext();
  const recent = conversations.slice(0, 5);

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="font-display text-2xl text-paper-100">Welcome back, {user?.name?.split(" ")[0]}</h1>
      <p className="mt-1 text-sm text-paper-500">Here's a quick look at your activity.</p>

      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="rounded-xl2 border border-ink-600 bg-ink-800 p-5 shadow-card">
          <p className="text-xs uppercase tracking-wide text-paper-500">Conversations</p>
          <p className="mt-2 font-display text-3xl text-paper-100">{conversations.length}</p>
        </div>
        <Link to="/app/chats/new" className="flex flex-col justify-between rounded-xl2 border border-amber-500/40 bg-amber-500/10 p-5 shadow-card hover:bg-amber-500/15 transition-colors">
          <MessageSquarePlus className="text-amber-400" size={20} />
          <p className="mt-2 text-sm font-medium text-paper-100">Start a new chat</p>
        </Link>
      </div>

      <div className="mt-8">
        <p className="mb-3 text-xs uppercase tracking-wide text-paper-500">Recent conversations</p>
        {recent.length === 0 ? (
          <p className="text-sm text-paper-500">No conversations yet - start your first one above.</p>
        ) : (
          <div className="space-y-2">
            {recent.map((c) => (
              <Link
                key={c.id}
                to={`/app/chats/${c.id}`}
                className="flex items-center gap-3 rounded-lg border border-ink-600 bg-ink-800 px-4 py-3 hover:bg-ink-700 transition-colors"
              >
                <MessagesSquare size={15} className="text-paper-500" />
                <span className="flex-1 truncate text-sm text-paper-100">{c.title}</span>
                <span className="flex items-center gap-1 text-xs text-paper-500">
                  <Clock size={11} /> {new Date(c.created_at).toLocaleDateString()}
                </span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
