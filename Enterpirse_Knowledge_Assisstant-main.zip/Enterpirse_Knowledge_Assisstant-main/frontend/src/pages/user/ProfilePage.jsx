import { useState } from "react";
import { User as UserIcon, Check } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useToast } from "../../context/ToastContext";
import { Badge } from "../../components/Badge";
import { authService } from "../../services/authService";

export function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const toast = useToast();
  const [name, setName] = useState(user?.name || "");
  const [saving, setSaving] = useState(false);

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await authService.updateProfile(name);
      await refreshUser();
      toast.push("Profile updated");
    } catch (err) {
      toast.push(err.message, "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="font-display text-2xl text-paper-100">Profile</h1>
      <p className="mt-1 text-sm text-paper-500">Your own account information.</p>

      <div className="mt-6 rounded-xl2 border border-ink-600 bg-ink-800 p-6 shadow-card">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-amber-500/15 border border-amber-500/30">
            <UserIcon size={22} className="text-amber-400" />
          </div>
          <div>
            <p className="text-lg font-medium text-paper-100">{user?.name}</p>
            <p className="text-sm text-paper-500">{user?.email}</p>
          </div>
          <Badge tone={user?.role === "ADMIN" ? "teal" : "neutral"}>{user?.role}</Badge>
        </div>

        <dl className="mt-6 grid grid-cols-2 gap-4 text-sm">
          <div>
            <dt className="text-xs uppercase tracking-wide text-paper-500">Member since</dt>
            <dd className="mt-1 text-paper-100">{user?.created_at ? new Date(user.created_at).toLocaleDateString() : "-"}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-paper-500">Last login</dt>
            <dd className="mt-1 text-paper-100">{user?.last_login_at ? new Date(user.last_login_at).toLocaleString() : "-"}</dd>
          </div>
        </dl>

        <form onSubmit={save} className="mt-6 border-t border-ink-600 pt-5">
          <label className="mb-1.5 block text-xs font-medium text-paper-300">Display name</label>
          <div className="flex gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="flex-1 rounded-lg border border-ink-600 bg-ink-900 px-3 py-2.5 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
            />
            <button type="submit" disabled={saving} className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-2.5 text-sm font-medium text-ink-950 hover:bg-amber-400 disabled:opacity-60 transition-colors">
              <Check size={14} /> {saving ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
