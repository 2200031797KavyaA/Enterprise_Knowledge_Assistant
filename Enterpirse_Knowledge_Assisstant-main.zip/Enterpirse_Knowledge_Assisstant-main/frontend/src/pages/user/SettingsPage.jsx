import { useState } from "react";
import { Lock } from "lucide-react";
import { authService } from "../../services/authService";
import { useToast } from "../../context/ToastContext";
import { PasswordStrength, isPasswordStrong } from "../../components/PasswordStrength";

export function SettingsPage() {
  const toast = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (!isPasswordStrong(next)) {
      setError("New password doesn't meet the requirements below.");
      return;
    }
    if (next !== confirm) {
      setError("New passwords do not match.");
      return;
    }
    setSubmitting(true);
    try {
      await authService.changePassword(current, next, confirm);
      toast.push("Password changed");
      setCurrent("");
      setNext("");
      setConfirm("");
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="font-display text-2xl text-paper-100">Settings</h1>
      <p className="mt-1 text-sm text-paper-500">Manage your account security.</p>

      <form onSubmit={submit} className="mt-6 rounded-xl2 border border-ink-600 bg-ink-800 p-6 shadow-card space-y-4">
        <div className="flex items-center gap-2 text-sm font-medium text-paper-100">
          <Lock size={15} className="text-amber-400" /> Change password
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-medium text-paper-300">Current password</label>
          <input
            type="password"
            required
            value={current}
            onChange={(e) => setCurrent(e.target.value)}
            className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2.5 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-medium text-paper-300">New password</label>
          <input
            type="password"
            required
            value={next}
            onChange={(e) => setNext(e.target.value)}
            className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2.5 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
          />
        </div>

        {next.length > 0 && <PasswordStrength password={next} />}

        <div>
          <label className="mb-1.5 block text-xs font-medium text-paper-300">Confirm new password</label>
          <input
            type="password"
            required
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            className="w-full rounded-lg border border-ink-600 bg-ink-900 px-3 py-2.5 text-sm text-paper-100 outline-none focus:border-amber-500 transition-colors"
          />
        </div>

        {error && (
          <div className="rounded-lg border border-coral-500/40 bg-coral-500/10 px-3 py-2 text-xs text-coral-500">{error}</div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="rounded-lg bg-amber-500 px-4 py-2.5 text-sm font-medium text-ink-950 hover:bg-amber-400 disabled:opacity-60 transition-colors"
        >
          {submitting ? "Updating..." : "Update password"}
        </button>
      </form>
    </div>
  );
}
