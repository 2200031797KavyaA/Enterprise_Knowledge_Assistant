import { apiClient } from "./apiClient";

export const adminService = {
  listUsers: () => apiClient.get("/api/admin/users"),
  setUserActive: (userId, isActive) => apiClient.patch(`/api/admin/users/${userId}/active`, { is_active: isActive }),
  setUserRole: (userId, role) => apiClient.patch(`/api/admin/users/${userId}/role`, { role }),

  listAllConversations: (includeDeleted = true) =>
    apiClient.get(`/api/admin/conversations?include_deleted=${includeDeleted}`),
  getConversationMessages: (conversationId) =>
    apiClient.get(`/api/admin/conversations/${conversationId}/messages`),
  restoreConversation: (conversationId) => apiClient.post(`/api/admin/conversations/${conversationId}/restore`, {}),
  permanentlyDeleteConversation: (conversationId) => apiClient.del(`/api/admin/conversations/${conversationId}/permanent`),

  listRestoreRequests: (status) => apiClient.get(`/api/admin/restore-requests${status ? `?status=${status}` : ""}`),
  resolveRestoreRequest: (requestId, approve, resolutionReason) =>
    apiClient.post(`/api/admin/restore-requests/${requestId}/resolve`, { approve, resolution_reason: resolutionReason || null }),

  auditLogs: (limit = 200) => apiClient.get(`/api/admin/audit-logs?limit=${limit}`),
  analyticsOverview: () => apiClient.get("/api/admin/analytics/overview"),
};
