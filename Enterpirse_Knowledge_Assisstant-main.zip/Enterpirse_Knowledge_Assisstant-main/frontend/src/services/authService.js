import { apiClient, tokenStore } from "./apiClient";

export const authService = {
  register: (name, email, password, confirmPassword) =>
    apiClient.post("/api/auth/register", { name, email, password, confirm_password: confirmPassword }),
  login: (email, password) => apiClient.post("/api/auth/login", { email, password }),
  me: () => apiClient.get("/api/auth/me"),
  updateProfile: (name) => apiClient.patch("/api/auth/me", { name }),
  changePassword: (currentPassword, newPassword, confirmNewPassword) =>
    apiClient.post("/api/auth/change-password", {
      current_password: currentPassword,
      new_password: newPassword,
      confirm_new_password: confirmNewPassword,
    }),
  logout: () => tokenStore.clear(),
};
