import { apiClient } from "./apiClient";

export const restoreRequestService = {
  listDeletedConversations: () => apiClient.get("/api/conversations/deleted"),
  submit: (conversationId, reason) =>
    apiClient.post(`/api/conversations/${conversationId}/restore-requests`, { reason }),
  mine: () => apiClient.get("/api/conversations/restore-requests/mine"),
};
